# 1.1.9 - 10/09/2020
- Fixed: appear twice price in single product
- Improved: Update quantity in screen cart

# 1.1.8 - 09/09/2020
- Fixed: App hangs on the Onboarding screens when the Require Login option is switched on
- Fixed: Cash app in text input address

# 1.1.4 - 10/08/2020
- Fixed: Pagination on store list page

# 1.1.3 - 10/08/2020
- Improved: validate register input fields
- Chore: Disable the button add to cart in out of stock
- Fix: get image product cart
- Updated: Cart Rest API

## 1.1.2 - 05/08/2020
- Chore: translate `+ add` in ProductItem3
- Fixed: lost the icon shop when turn off wishlist
- Improvement: update loading remove cart and loading change quantity item cart
- Add: Out of stock product item and number stock on product detail

## 1.1.1 - 28/07/2020
- Fixed: get vendor in product detail
- Improvement: Order by popularity when user search products
- Improvement: Change qty in cart screen
- Removed: Ignore warning functions
