export const API = 'https://food.rnlab.io';

export const CONSUMER_KEY = 'ck_f3b113414fc6f6b58df59791c231bb390364e3e6';
export const CONSUMER_SECRET = 'cs_1693429998e6d95c769c0e46a75627bf2f2c0325';

export default {
  API_ENDPOINT: API,
  CONSUMER_KEY,
  CONSUMER_SECRET,
};
