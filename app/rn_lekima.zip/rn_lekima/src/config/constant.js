export const GOOGLE_API_KEY = 'YOUR_GOOGLE_MAP_API_KEY';

export const LOCATION_DEFAULT = {
  latitude: 20.9935273,
  longitude: 105.8022073,
};

export const CONTACT_GEO_LOCATION = {
  lat: 20.990721,
  lng: 105.787064,
};
