export const INITIAL_COUNTRY = 'in';
