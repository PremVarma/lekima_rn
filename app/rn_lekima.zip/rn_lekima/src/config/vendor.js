export const vendor = 'wcfm';
export const plugin_name = 'mobile-builder';
