export const APP_NAME = 'Lekima';
export const APP_VERSION = '1.0.0';
