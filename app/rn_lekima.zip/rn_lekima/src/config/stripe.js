export const PUBLISHABLE_KEY = 'pk_test_C0vSyRyyJOwid3Pcd4ffOodY00GzLrCx3w';
