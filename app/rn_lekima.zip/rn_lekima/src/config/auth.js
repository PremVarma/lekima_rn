export const GOOGLE_SIGN_IN_CONFIG = {
  webClientId:
    '871078371322-aavesl7p6i5t4anad0o9qjpe3afnlemv.apps.googleusercontent.com',
  offlineAccess: true,
};
