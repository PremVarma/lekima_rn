import MapView from './ClusteredMapView';

module.exports = MapView;
