export const vendorFoodSimple = [
  {
    id: 5,
    store_name: 'Foody - Hoang Dao Thuy',
    first_name: 'Jon',
    last_name: 'Doe',
    email: 'jon@yahoo.com',
    social: {
      fb: 'https://wedevs.com/docs/dokan/developer-documentation/rest-api/',
      gplus: false,
      twitter:
        'https://wedevs.com/docs/dokan/developer-documentation/rest-api/',
      pinterest:
        'https://wedevs.com/docs/dokan/developer-documentation/rest-api/',
      linkedin: '',
      youtube: false,
      instagram:
        'https://wedevs.com/docs/dokan/developer-documentation/rest-api/',
      flickr: false,
    },
    phone: '3493948',
    show_email: false,
    address: {
      street_1: '',
      street_2: '',
      city: '',
      zip: '',
      country: 'BD',
      state: 'DHA',
    },
    location: '',
    banner:
      'https://oreo-cdn.nyc3.cdn.digitaloceanspaces.com/food/uploads/2020/04/29041814/pexels-photo-3962294.jpeg',
    gravatar:
      'https://oreo-cdn.nyc3.cdn.digitaloceanspaces.com/food/uploads/2020/04/29041756/Burger_King_Logo.svg_.png',
    products_per_page: 10,
    show_more_product_tab: true,
    toc_enabled: false,
    store_toc: null,
    featured: false,
    rating: {
      rating: '4.27',
      count: 11,
    },
    preferred: true,
    promotion: true,
    free_ship: true,
    pick_up: true,
    description:
      'Lorem Ipsum is simply dummy text of the printing and typesetting industry',
  },
  {
    id: 12,
    store_name: 'Foody - Le Loi',
    first_name: 'sendbox',
    last_name: 'saimon',
    email: 'st@gmail.com',
    social: {
      fb: 'https://wedevs.com/docs/dokan/developer-documentation/rest-api/',
      gplus: false,
      twitter:
        'https://wedevs.com/docs/dokan/developer-documentation/rest-api/',
      pinterest:
        'https://wedevs.com/docs/dokan/developer-documentation/rest-api/',
      linkedin: '',
      youtube: false,
      instagram:
        'https://wedevs.com/docs/dokan/developer-documentation/rest-api/',
      flickr: false,
    },
    phone: '3493948',
    show_email: false,
    address: {
      street_1: '',
      street_2: '',
      city: '',
      zip: '',
      country: 'BD',
      state: 'DHA',
    },
    location: '',
    banner:
      'https://oreo-cdn.nyc3.cdn.digitaloceanspaces.com/food/uploads/2020/04/29041814/pexels-photo-3962294.jpeg',
    gravatar:
      'https://oreo-cdn.nyc3.cdn.digitaloceanspaces.com/food/uploads/2020/04/29041756/Burger_King_Logo.svg_.png',
    products_per_page: 10,
    show_more_product_tab: true,
    toc_enabled: false,
    store_toc: null,
    featured: false,
    rating: {
      rating: '0.00',
      count: 0,
    },
    preferred: true,
    promotion: true,
    free_ship: true,
    pick_up: true,
    description:
      'Lorem Ipsum is simply dummy text of the printing and typesetting industry',
  },
];
